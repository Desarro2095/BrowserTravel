USE BrowserTravel;

-- Query A
SELECT COUNT(DISTINCT P.DocumentNumber) 
FROM person P
INNER JOIN personreservation PR ON PR.PersonId = P.PersonId
INNER JOIN reservation R ON R.ReservationId = PR.ReservationId
		   AND R.Total > 1000; 
           
-- Query B
SELECT P.DocumentNumber, P.FirstName, P.LastName 
FROM person P
INNER JOIN personreservation PR ON PR.PersonId = P.PersonId
INNER JOIN city C ON C.CityId = P.CityId AND City = 'Bogota'
GROUP BY P.DocumentNumber, P.FirstName, P.LastName;

-- Query C
SELECT R.ReservationId, DateBegin, DateEnd
FROM reservation R
INNER JOIN paymethod PM ON PM.PayMethodId = R.PayMethodId AND PM.Method = 'Credit Card'
ORDER BY R.ReservationId;

-- Query D
SELECT R.ReservationId, DateBegin, DateEnd
FROM reservation R
INNER JOIN paymethod PM ON PM.PayMethodId = R.PayMethodId AND PM.Method = 'Pay in destiny'
ORDER BY R.ReservationId;

-- Query E
SELECT R.ReservationId, DateBegin, DateEnd
FROM reservation R
WHERE R.Confirmation = 1 AND R.Cancelled = 1
ORDER BY R.ReservationId;


