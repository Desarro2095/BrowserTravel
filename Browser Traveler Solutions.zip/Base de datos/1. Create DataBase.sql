CREATE DATABASE BrowserTravel;
USE BrowserTravel;

CREATE TABLE City(
	CityId INT NOT NULL AUTO_INCREMENT,
    City VARCHAR(100) NOT NULL,
    PRIMARY KEY(CityId)
);

CREATE TABLE PayMethod(
	PayMethodId INT NOT NULL AUTO_INCREMENT,
    Method VARCHAR(100) NOT NULL,
    PRIMARY KEY(PayMethodId)
);

CREATE TABLE Vehicle(
	VehicleId INT NOT NULL AUTO_INCREMENT,
    Vehicle VARCHAR(100) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    PRIMARY KEY(VehicleId)
);

CREATE TABLE Person(
	PersonId INT NOT NULL AUTO_INCREMENT,
    DocumentNumber VARCHAR(11) NOT NULL,
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Age INT NOT NULL,
    CityId INT NOT NULL,
    INDEX (PersonId, DocumentNumber),
    FOREIGN KEY (CityId) REFERENCES City(CityId),
    PRIMARY KEY(PersonId)
);

CREATE TABLE Reservation(
	ReservationId INT NOT NULL AUTO_INCREMENT,
    DateBegin DATETIME NOT NULL,
    DateEnd DATETIME NOT NULL,
    Total DECIMAL(10,2) NOT NULL,
    VehicleId INT NOT NULL,
    PayMethodId INT NOT NULL,
    Confirmation BIT NOT NULL,
    Cancelled BIT NOT NULL,
    FOREIGN KEY (VehicleId) REFERENCES Vehicle(VehicleId),
    FOREIGN KEY (PayMethodId) REFERENCES PayMethod(PayMethodId),
    PRIMARY KEY(ReservationId)
);

CREATE TABLE PersonReservation(
    PersonId INT NOT NULL,
    ReservationId INT NOT NULL,
    FOREIGN KEY (PersonId) REFERENCES Person(PersonId),
    FOREIGN KEY (ReservationId) REFERENCES Reservation(ReservationId),
    PRIMARY KEY(PersonId, ReservationId)
);




